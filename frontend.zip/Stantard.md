TRAVELNEST DESIGN SYSTEM (FINAL STANDARD)
This will become your:
single source of truth
for:

<Home>

<Nav />

<HeroSection />

<FloatingSearch />

<Categories />

<TrendingSection />

<BannerSection />

<DestinationSection />

<WhyChooseSection />

<Testimonials />

<FAQ />

<Footer />

</Home>


Folder Structure

src/
│
├── assets/
│
├── components/
│   │
│   ├── layout/
│   │   ├── Navbar.jsx
│   │   ├── Footer.jsx
│   │   ├── Container.jsx
│   │   ├── PageWrapper.jsx
│   │
│   ├── home/
│   │   ├── Header.jsx
│   │   ├── HeroSection.jsx
│   │   ├── FloatingSearch.jsx
│   │   ├── Categories.jsx
│   │   ├── TrendingSection.jsx
│   │   ├── BannerSection.jsx
│   │   ├── DestinationSection.jsx
│   │   ├── WhyChooseSection.jsx
│   │   ├── Testimonials.jsx
│   │   ├── FAQ.jsx
│   │   ├── Newsletter.jsx
│   │
│   ├── listing/
│   │   ├── Card.jsx
│   │   ├── ListingGrid.jsx
│   │   ├── ListingGallery.jsx
│   │   ├── ListingDetails.jsx
│   │   ├── BookingWidget.jsx
│   │
│   ├── ui/
│   │   ├── Button.jsx
│   │   ├── Input.jsx
│   │   ├── Modal.jsx
│   │   ├── SectionTitle.jsx
│   │   ├── EmptyState.jsx
│   │   ├── Skeleton.jsx
│   │
│   ├── profile/
│   │
│   ├── booking/
│   │
│   ├── wishlist/
│
├── Context/
│
├── pages/
│   ├── Home.jsx
│   ├── Login.jsx
│   ├── Signup.jsx
│   ├── ListingPage.jsx
│   ├── Profile.jsx
│   ├── Wishlist.jsx
│
├── routes/
│
├── utils/
│
├── hooks/
│
├── App.jsx
├── main.jsx
├── index.css 


spacing


colors


typography


shadows


radius


containers


buttons


sections


cards


navbar


footer


DO NOT randomly choose values anymore.

1. BRAND COLORS
PRIMARY BRAND
#FF385C
Use for:


buttons


active states


icons


highlights


CTA



PRIMARY HOVER
#E31C5F

LIGHT BACKGROUND
#FAFAFA
NEVER pure white for page background.

DARK BACKGROUND
#020617
Tailwind:
slate-950

CARD BACKGROUND
Light
#FFFFFF
Dark
#0F172A
Tailwind:
dark:bg-slate-900

TEXT COLORS
Primary Text
#111827
Tailwind:
text-gray-900

Secondary Text
#6B7280
Tailwind:
text-gray-500

Dark Secondary
#94A3B8
Tailwind:
dark:text-slate-400

BORDERS
Light
border-gray-200
Dark
dark:border-slate-800

2. TYPOGRAPHY SYSTEM
FONT FAMILY
Use ONLY:
font-sans
Best options:


Inter


Plus Jakarta Sans


Manrope



RECOMMENDED
Inter
Professional startup feel.

HOW TO ADD
index.html
<link  rel="preconnect"  href="https://fonts.googleapis.com"/><link  rel="preconnect"  href="https://fonts.gstatic.com"  crossorigin/><link  href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap"  rel="stylesheet"/>

tailwind.config.js
theme: {  extend: {    fontFamily: {      sans: ['Inter', 'sans-serif'],    },  },},

TYPOGRAPHY SCALE
HERO TITLE
text-6xlfont-[800]tracking-[-3px]leading-[1]

SECTION TITLE
text-4xlfont-boldtracking-[-1px]

CARD TITLE
text-[17px]font-semiboldleading-snug

BODY TEXT
text-baseleading-relaxed

SMALL TEXT
text-sm

BUTTON TEXT
text-smfont-semibold

NAVBAR TEXT
text-smfont-medium

FOOTER TITLES
text-smuppercasetracking-widefont-semibold

3. CONTAINER SYSTEM
ALL sections use:
max-w-[1400px]mx-autopx-6lg:px-10

SECTION SPACING
STANDARD SECTION
py-20

SMALL SECTION
py-14

HERO SECTION
pt-32pb-24

4. SPACING SYSTEM
ONLY USE:
12468101214162024
DO NOT use random values everywhere.

GAP SYSTEM
Cards
gap-6

Sections
gap-10

Hero Columns
gap-16

5. BORDER RADIUS SYSTEM
ONLY:
rounded-xlrounded-2xlrounded-3xlrounded-full

STANDARD USAGE
Buttons
rounded-full

Cards
rounded-3xl

Inputs
rounded-2xl

Banner
rounded-[40px]

6. SHADOW SYSTEM
STANDARD
shadow-[0_8px_30px_rgba(0,0,0,0.06)]

HOVER
hover:shadow-[0_12px_40px_rgba(0,0,0,0.1)]

DARK SHADOW
dark:shadow-[0_8px_30px_rgba(0,0,0,0.35)]

7. BUTTON SYSTEM
PRIMARY BUTTON
h-14px-8rounded-fullbg-[#FF385C]hover:bg-[#E31C5F]text-whitefont-semiboldtransition-allduration-300

SECONDARY BUTTON
h-14px-8rounded-fullborderbg-whitehover:bg-gray-100

8. INPUT SYSTEM
STANDARD INPUT
h-14rounded-2xlborderborder-gray-200bg-whitepx-5text-smoutline-nonefocus:border-[#FF385C]

DARK INPUT
dark:bg-slate-900dark:border-slate-700dark:text-white

9. CARD SYSTEM
LISTING CARD
bg-whitedark:bg-slate-900rounded-3xloverflow-hiddentransition-allduration-300hover:-translate-y-1

CARD IMAGE
h-64object-cover

CARD CONTENT
p-5

10. NAVBAR SYSTEM
HEIGHT
h-[80px]

STYLE
fixedtop-0z-50backdrop-blur-xlbg-white/80dark:bg-slate-950/80border-b

11. FOOTER SYSTEM
TOP SPACING
pt-20

MAIN GRID
py-14

NEWSLETTER
rounded-[36px]py-8

12. ANIMATION SYSTEM
STANDARD TRANSITION
transition-allduration-300

CARD HOVER
hover:-translate-y-1

BUTTON HOVER
hover:scale-[1.02]

13. ICON SYSTEM
STANDARD ICON SIZE
w-5 h-5

SMALL ICON
w-4 h-4

14. RESPONSIVE RULES
MOBILE
px-4

TABLET
md:px-6

DESKTOP
lg:px-10

15. MOST IMPORTANT RULES
DO NOT
❌ random font sizes
❌ random spacing
❌ random colors
❌ random shadows
❌ random radius.

ALWAYS USE
your:
design system.

FINAL RESULT
If you consistently follow this system,
TravelNest will feel:
✅ cohesive
✅ premium
✅ production-level
✅ scalable
✅ modern startup quality.